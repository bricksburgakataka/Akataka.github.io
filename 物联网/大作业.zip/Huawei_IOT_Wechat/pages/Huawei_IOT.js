// pages/Huawei_IOT.js

// 设置温度值和湿度值 
var Temp = null;
var Phot = null;
var RED = '';
var GREEN = '';
var BLUE = '';
var RGBtemp = [0, 0, 0, 0, 0];
var BreathingMode = 0;
var BreathingColor = 0;
var Frequency = 3;

// 设置用户登录参数，此处需要全部修改替换为真实参数
const domainname = 'bricksburgakataka';
const username = 'Wechat01';
const password = 'lego0369';
const projectId = '2c1b69ce3828429fb0682557f8309123';

// 设备ID - 修改为摄像头设备
const deviceId = '690343cb0a9ab42ae589dd21_CAM01';
const iamhttps = 'iam.cn-east-3.myhuaweicloud.com';
const iotdahttps = '943f583bff.st1.iotda-app.cn-east-3.myhuaweicloud.com';

Page({
    /**
     * 页面的初始数据
     */
    data: {
        result: '等待订阅，请点击 订阅按钮',
        
        // 系统状态数据
        systemUptime: "0分钟",
        photoCount: "0",
        messageCount: "0",
        aiDetectionCount: "0",
        errorCount: "0",
        lastActivity: "系统启动",
        
        // 控制参数
        deviceSwitch: true,
        captureInterval: 30,
        autoUpload: true,
        enableAI: true,
        
        // 天气信息
        temperature: "--°C",
        city: "杭州",
        condition: "未知",
        humidity: "--",
        windScale: "--",
        updateTime: "--",
        
        // AI识别结果
        aiResult: "暂无AI识别结果",
        aiResultType: "none",
        hasAIResult: false,
        
        // 图片相关
        imageURL: "",
        latestImageBase64: "",
        isImageLoading: false,
        hasImage: false,
        
        // 日程提醒
        hasScheduleReminder: false,
        scheduleContent: "",
        scheduleTime: "",
        
        // 开关状态
        switch1Checked: true,
        switch2Checked: false,
        switch1Style: '',
        switch2Style: 'text-decoration: line-through',
        switchLight: false,
        switchbreathingMode: false,

        // 新增的数据
        currentTime: '', // 当前时间
        activeTab: 'home', // 当前激活的标签
        showScheduleModal: false, // 是否显示日程模态框
        showAddScheduleModal: false, // 是否显示添加日程模态框
        scheduleList: [], // 日程列表
        todayScheduleCount: 0, // 今日日程数量
        newSchedule: { // 新日程数据
            title: '',
            time: '',
            description: ''
        }
    },

    /**
     * 订阅按钮按下：
     */
    touchBtn_subTopic: function() {
        console.log("订阅按钮按下");
        this.setData({ result: '订阅按钮按下' });
        this.gettoken();
    },

    /**
     * 获取设备影子按钮按下：
     */
    touchBtn_getshadow: function() {
        console.log("获取设备影子按钮按下");
        this.setData({ result: '获取设备影子按钮按下' });
        this.getshadow();
    },

    /**
     * 拍照命令下发按钮按下：
     */
    touchBtn_takePhoto: function() {
        console.log("拍照命令下发按钮按下");
        this.setData({ 
            result: '拍照命令下发按钮按下，正在下发。。。',
            isImageLoading: true
        });
        this.sendTakePhotoCommand();
    },

    /**
     * 系统控制命令下发：
     */
    touchBtn_systemControl: function() {
        console.log("系统控制命令下发");
        this.setData({ result: '系统控制命令下发，正在下发。。。' });
        this.sendSystemControlCommand();
    },

    /**
     * 获取天气数据按钮：
     */
    touchBtn_getWeather: function() {
        console.log("获取天气数据按钮按下");
        this.setData({ result: '获取天气数据按钮按下' });
        this.sendWeatherUpdateCommand();
    },

    /**
     * 发送拍照命令
     */
    sendTakePhotoCommand: function() {
        console.log("发送拍照命令。。。");
        var that = this;
        var token = wx.getStorageSync('token');
        
        // 立即更新UI状态
        this.setData({ 
            isImageLoading: true,
            result: '正在发送拍照命令...'
        });
        
        wx.request({
            url: `https://${iotdahttps}/v5/iot/${projectId}/devices/${deviceId}/commands`,
            data: `{
                "service_id": "ESP32CAM01",
                "command_name": "TakePhoto",
                "paras": {
                    "TakePhoto": true
                }
            }`,
            method: 'POST',
            header: { 'content-type': 'application/json', 'X-Auth-Token': token },
            success: function(res) {
                console.log("拍照命令下发成功");
                console.log(res);
                that.setData({
                    result: '拍照命令下发成功，等待设备响应...'
                });
                
                // 5秒后获取最新状态
                setTimeout(() => {
                    that.getshadow();
                }, 5000);
                
                // 10秒后强制重置加载状态（防止设备无响应）
                setTimeout(() => {
                    that.setData({
                        isImageLoading: false
                    });
                }, 10000);
            },
            fail: function() {
                console.log("拍照命令下发失败");
                that.setData({
                    result: '拍照命令下发失败，请检查网络连接',
                    isImageLoading: false
                });
            }
        });
    },

    /**
     * 发送系统控制命令
     */
    sendSystemControlCommand: function() {
        console.log("发送系统控制命令。。。");
        var that = this;
        var token = wx.getStorageSync('token');
        wx.request({
            url: `https://${iotdahttps}/v5/iot/${projectId}/devices/${deviceId}/commands`,
            data: `{
                "service_id": "ESP32CAM01",
                "command_name": "SystemControl",
                "paras": {
                    "DeviceSwitch": ${this.data.deviceSwitch},
                    "CaptureInterval": ${this.data.captureInterval},
                    "AutoUpload": ${this.data.autoUpload},
                    "EnableAI": ${this.data.enableAI}
                }
            }`,
            method: 'POST',
            header: { 'content-type': 'application/json', 'X-Auth-Token': token },
            success: function(res) {
                console.log("系统控制命令下发成功");
                console.log(res);
                that.setData({
                    result: '系统控制命令下发成功'
                });
            },
            fail: function() {
                console.log("系统控制命令下发失败");
                that.setData({
                    result: '系统控制命令下发失败'
                });
            }
        });
    },

    /**
     * 发送天气更新命令
     */
    sendWeatherUpdateCommand: function() {
        console.log("发送天气更新命令。。。");
        var that = this;
        var token = wx.getStorageSync('token');
        wx.request({
            url: `https://${iotdahttps}/v5/iot/${projectId}/devices/${deviceId}/commands`,
            data: `{
                "service_id": "ESP32CAM01",
                "command_name": "WeatherUpdate",
                "paras": {
                    "City": "杭州",
                    "Temp": "25",
                    "Condition": "晴",
                    "Humidity": "65",
                    "WindScale": "3"
                }
            }`,
            method: 'POST',
            header: { 'content-type': 'application/json', 'X-Auth-Token': token },
            success: function(res) {
                console.log("天气更新命令下发成功");
                that.setData({
                    result: '天气更新命令下发成功'
                });
                
                // 2秒后获取最新状态
                setTimeout(() => {
                    that.getshadow();
                }, 2000);
            },
            fail: function() {
                console.log("天气更新命令下发失败");
                that.setData({
                    result: '天气更新命令下发失败'
                });
            }
        });
    },

    /**
     * 开关控制
     */
    switchDevice: function(e) {
        const value = e.detail.value;
        this.setData({
            deviceSwitch: value,
            result: value ? '设备已开启' : '设备已关闭'
        });
        console.log('设备开关:', value);
    },

    switchAutoUpload: function(e) {
        const value = e.detail.value;
        this.setData({
            autoUpload: value,
            result: value ? '自动上传已开启' : '自动上传已关闭'
        });
        console.log('自动上传:', value);
    },

    switchEnableAI: function(e) {
        const value = e.detail.value;
        this.setData({
            enableAI: value,
            result: value ? 'AI识别已开启' : 'AI识别已关闭'
        });
        console.log('AI识别:', value);
    },

    /**
     * 拍照间隔滑动条
     */
    sliderCaptureInterval: function(e) {
        const value = e.detail.value;
        this.setData({
            captureInterval: value
        });
        console.log('拍照间隔:', value, '秒');
    },

    /**
     * 获取token
     */
    gettoken: function() {
        console.log("开始获取token。。。");
        var that = this;
        wx.request({
            url: `https://${iamhttps}/v3/auth/tokens`,
            data: `{"auth": { "identity": {"methods": ["password"],"password": {"user": {"name": "${username}","password": "${password}","domain": {"name": "${domainname}"}}}},"scope": {"project": {"name": "cn-east-3"}}}}`,
            method: 'POST',
            header: { 'content-type': 'application/json' },
            success: function(res) {
                console.log("获取token成功");
                var token = JSON.stringify(res.header['X-Subject-Token']);
                token = token.replaceAll("\"", "");
                console.log("获取token=\n" + token);
                wx.setStorageSync('token', token);
                that.setData({ result: 'Token获取成功，可以获取设备状态' });
            },
            fail: function() {
                console.log("获取token失败");
                that.setData({ result: 'Token获取失败' });
            },
            complete: function() {
                console.log("获取token完成");
            }
        });
    },

    /**
     * 获取设备影子
     */
    getshadow: function() {
        console.log("开始获取影子");
        var that = this;
        var token = wx.getStorageSync('token');
        wx.request({
            url: `https://${iotdahttps}/v5/iot/${projectId}/devices/${deviceId}/shadow`,
            data: '',
            method: 'GET',
            header: { 'content-type': 'application/json', 'X-Auth-Token': token },
            success: function(res) {
                console.log("获取影子成功");
                console.log(res);
                
                // 检查响应数据结构
                if (res.data && res.data.shadow && res.data.shadow.length > 0) {
                    var shadow = JSON.stringify(res.data.shadow[0].reported.properties);
                    console.log('设备影子数据：' + shadow);
                    
                    var properties = res.data.shadow[0].reported.properties;
                    
                    // 提取图片数据
                    that.extractImageData(properties);
                    
                    // 解析系统状态 - 添加默认值
                    that.setData({
                        systemUptime: properties.SystemUptime ? (properties.SystemUptime / 60).toFixed(1) + '分钟' : '0分钟',
                        photoCount: properties.PhotoCount || 0,
                        messageCount: properties.MessageCount || 0,
                        aiDetectionCount: properties.AIDetectionCount || 0,
                        errorCount: properties.ErrorCount || 0,
                        lastActivity: properties.LastActivity || '无活动'
                    });
                    
                    // 解析控制参数 - 添加默认值
                    that.setData({
                        deviceSwitch: properties.DeviceSwitch !== undefined ? properties.DeviceSwitch : true,
                        captureInterval: properties.CaptureInterval || 30,
                        autoUpload: properties.AutoUpload !== undefined ? properties.AutoUpload : true,
                        enableAI: properties.EnableAI !== undefined ? properties.EnableAI : true
                    });
                    
                    // 解析天气信息 - 确保即使数据不全也能显示
                    that.setData({
                        temperature: properties.Temp && properties.Temp !== "N/A" ? properties.Temp + '°C' : '--°C',
                        city: properties.City || '杭州',
                        condition: properties.Condition || '未知',
                        humidity: properties.Humidity && properties.Humidity !== "N/A" ? properties.Humidity : '--',
                        windScale: properties.WindScale && properties.WindScale !== "N/A" ? properties.WindScale : '--',
                        updateTime: properties.UpdateTime && properties.UpdateTime !== "N/A" ? properties.UpdateTime : '--'
                    });
                    
                    // 解析AI结果
                    if (properties.AIResult && properties.AIResult !== "暂无AI识别结果") {
                        that.setData({
                            aiResult: properties.AIResult,
                            aiResultType: properties.AIResultType || 'none',
                            hasAIResult: properties.HasAIResult || false
                        });
                        
                        // 检查是否有日程提醒
                        that.checkScheduleReminder(properties.AIResult);
                    } else {
                        that.setData({
                            aiResult: "暂无AI识别结果",
                            hasAIResult: false
                        });
                    }
                } else {
                    console.log("影子数据格式异常，使用默认值");
                    // 设置默认值
                    that.setDefaultValues();
                }
                
                that.setData({ 
                    result: '设备状态更新成功',
                    isImageLoading: false
                });
            },
            fail: function() {
                console.log("获取影子失败");
                that.setData({ 
                    result: '获取影子失败，请先获取token',
                    isImageLoading: false
                });
                // 失败时也设置默认值
                that.setDefaultValues();
            },
            complete: function() {
                console.log("获取影子完成");
            }
        });
    },

    /**
     * 从设备影子中提取图片URL或base64数据
     */
    extractImageData: function(properties) {
        // 检查是否有图片URL
        if (properties.ImageURL && properties.ImageURL !== "N/A") {
            this.setData({
                imageURL: properties.ImageURL,
                hasImage: true
            });
        }
        
        // 检查是否有base64图片数据
        if (properties.LatestImageBase64 && properties.LatestImageBase64 !== "N/A") {
            this.setData({
                latestImageBase64: properties.LatestImageBase64,
                hasImage: true
            });
        }
        
        // 检查是否有照片计数
        if (properties.PhotoCount !== undefined) {
            this.setData({
                photoCount: properties.PhotoCount
            });
        }
    },

    /**
     * 查看最新照片
     */
    viewLatestPhoto: function() {
        if (this.data.imageURL) {
            // 如果有图片URL，直接预览
            wx.previewImage({
                urls: [this.data.imageURL],
                current: this.data.imageURL
            });
        } else if (this.data.latestImageBase64) {
            // 如果有base64图片数据，先转换为临时文件再预览
            const base64 = this.data.latestImageBase64;
            const filePath = `${wx.env.USER_DATA_PATH}/temp_photo_${Date.now()}.jpg`;
            
            // 将base64写入临时文件
            const fs = wx.getFileSystemManager();
            fs.writeFile({
                filePath: filePath,
                data: base64.replace(/^data:image\/\w+;base64,/, ''),
                encoding: 'base64',
                success: () => {
                    wx.previewImage({
                        urls: [filePath],
                        current: filePath
                    });
                },
                fail: (error) => {
                    console.error('写入临时文件失败:', error);
                    wx.showToast({
                        title: '图片加载失败',
                        icon: 'none'
                    });
                }
            });
        } else {
            wx.showToast({
                title: '暂无照片可查看',
                icon: 'none'
            });
        }
    },

    /**
     * 设置默认值
     */
    setDefaultValues: function() {
        this.setData({
            systemUptime: '0分钟',
            photoCount: 0,
            messageCount: 0,
            aiDetectionCount: 0,
            errorCount: 0,
            lastActivity: '系统启动',
            deviceSwitch: true,
            captureInterval: 30,
            autoUpload: true,
            enableAI: true,
            temperature: '--°C',
            city: '杭州',
            condition: '未知',
            humidity: '--',
            windScale: '--',
            updateTime: '--',
            aiResult: "暂无AI识别结果",
            hasAIResult: false,
            imageURL: "",
            latestImageBase64: "",
            hasImage: false
        });
    },

    /**
     * 检查日程提醒
     */
    checkScheduleReminder: function(aiResult) {
        // 简单的关键词匹配来检测日程提醒
        const scheduleKeywords = ['会议', '约会', '提醒', '日程', '任务', 'deadline', 'meeting', 'appointment'];
        const hasReminder = scheduleKeywords.some(keyword => 
            aiResult.includes(keyword)
        );
        
        if (hasReminder) {
            this.setData({
                hasScheduleReminder: true,
                scheduleContent: aiResult,
                scheduleTime: new Date().toLocaleString()
            });
        } else {
            this.setData({
                hasScheduleReminder: false
            });
        }
    },

    /**
     * 清除日程提醒
     */
    clearScheduleReminder: function() {
        this.setData({
            hasScheduleReminder: false,
            scheduleContent: "",
            scheduleTime: ""
        });
    },

    /**
     * 复制AI结果到剪贴板
     */
    copyAIResult: function() {
        wx.setClipboardData({
            data: this.data.aiResult,
            success: function() {
                wx.showToast({
                    title: 'AI结果已复制',
                    icon: 'success'
                });
            }
        });
    },

    /**
     * 更新当前时间 - 修复24小时制显示问题
     */
    updateCurrentTime: function() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        let seconds = now.getSeconds();
        
        // 确保两位数显示
        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;
        
        const timeString = `${hours}:${minutes}:${seconds}`;
        this.setData({
            currentTime: timeString
        });
    },

    /**
     * 切换标签
     */
    switchTab: function(e) {
        const tab = e.currentTarget.dataset.tab;
        this.setData({
            activeTab: tab
        });
        
        // 根据标签执行不同操作
        switch(tab) {
            case 'home':
                // 首页，不做特殊操作
                break;
            case 'schedule':
                this.showScheduleModal();
                break;
            case 'camera':
                // 直接触发拍照，但先检查设备状态
                if (!this.data.deviceSwitch) {
                    wx.showToast({
                        title: '设备已关闭，请先开启设备',
                        icon: 'none'
                    });
                    return;
                }
                this.touchBtn_takePhoto();
                break;
            case 'settings':
                // 可以展开设置面板等
                break;
        }
    },

    /**
     * 显示日程模态框
     */
    showScheduleModal: function() {
        this.setData({
            showScheduleModal: true
        });
    },

    /**
     * 隐藏日程模态框
     */
    hideScheduleModal: function() {
        this.setData({
            showScheduleModal: false
        });
    },

    /**
     * 显示添加日程模态框
     */
    showAddScheduleModal: function() {
        this.setData({
            showAddScheduleModal: true,
            newSchedule: {
                title: '',
                time: '',
                description: ''
            }
        });
    },

    /**
     * 隐藏添加日程模态框
     */
    hideAddScheduleModal: function() {
        this.setData({
            showAddScheduleModal: false
        });
    },

    /**
     * 加载日程列表
     */
    loadScheduleList: function() {
        // 从本地存储加载日程列表
        const scheduleList = wx.getStorageSync('scheduleList') || [];
        const today = new Date().toDateString();
        
        // 过滤出今日的日程
        const todaySchedules = scheduleList.filter(item => {
            const itemDate = new Date(item.date).toDateString();
            return itemDate === today;
        });
        
        this.setData({
            scheduleList: todaySchedules,
            todayScheduleCount: todaySchedules.length
        });
    },

    /**
     * 保存日程列表
     */
    saveScheduleList: function() {
        const allSchedules = wx.getStorageSync('scheduleList') || [];
        const today = new Date().toDateString();
        
        // 移除今日的旧日程
        const otherSchedules = allSchedules.filter(item => {
            const itemDate = new Date(item.date).toDateString();
            return itemDate !== today;
        });
        
        // 添加今日的新日程
        const updatedSchedules = [...otherSchedules, ...this.data.scheduleList];
        wx.setStorageSync('scheduleList', updatedSchedules);
    },

    /**
     * 添加新日程
     */
    addNewSchedule: function() {
        const { title, time, description } = this.data.newSchedule;
        
        if (!title.trim()) {
            wx.showToast({
                title: '请输入日程标题',
                icon: 'none'
            });
            return;
        }
        
        if (!time) {
            wx.showToast({
                title: '请选择时间',
                icon: 'none'
            });
            return;
        }
        
        const newSchedule = {
            id: Date.now().toString(),
            title: title.trim(),
            time: time,
            description: description.trim(),
            date: new Date().toISOString(),
            completed: false
        };
        
        const updatedList = [...this.data.scheduleList, newSchedule];
        this.setData({
            scheduleList: updatedList,
            todayScheduleCount: updatedList.length,
            showAddScheduleModal: false
        });
        
        this.saveScheduleList();
        
        wx.showToast({
            title: '日程添加成功',
            icon: 'success'
        });
    },

    /**
     * 切换日程完成状态
     */
    toggleSchedule: function(e) {
        const id = e.currentTarget.dataset.id;
        const updatedList = this.data.scheduleList.map(item => {
            if (item.id === id) {
                return { ...item, completed: !item.completed };
            }
            return item;
        });
        
        this.setData({
            scheduleList: updatedList
        });
        
        this.saveScheduleList();
    },

    /**
     * 删除日程
     */
    deleteSchedule: function(e) {
        const id = e.currentTarget.dataset.id;
        
        wx.showModal({
            title: '确认删除',
            content: '确定要删除这个日程吗？',
            success: (res) => {
                if (res.confirm) {
                    const updatedList = this.data.scheduleList.filter(item => item.id !== id);
                    this.setData({
                        scheduleList: updatedList,
                        todayScheduleCount: updatedList.length
                    });
                    
                    this.saveScheduleList();
                    
                    wx.showToast({
                        title: '删除成功',
                        icon: 'success'
                    });
                }
            }
        });
    },

    /**
     * 日程标题输入
     */
    onScheduleTitleInput: function(e) {
        this.setData({
            'newSchedule.title': e.detail.value
        });
    },

    /**
     * 日程时间选择
     */
    onScheduleTimeChange: function(e) {
        this.setData({
            'newSchedule.time': e.detail.value
        });
    },

    /**
     * 日程描述输入
     */
    onScheduleDescInput: function(e) {
        this.setData({
            'newSchedule.description': e.detail.value
        });
    },

    /**
     * 将AI识别结果添加到日程
     */
    addToSchedule: function() {
        const aiResult = this.data.aiResult;
        const currentTime = new Date();
        const timeString = currentTime.toTimeString().substring(0, 5);
        
        this.setData({
            'newSchedule.title': 'AI识别提醒',
            'newSchedule.time': timeString,
            'newSchedule.description': aiResult,
            showAddScheduleModal: true,
            hasScheduleReminder: false
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.gettoken();
        this.updateCurrentTime();
        this.loadScheduleList();
        
        // 设置定时器，每5秒获取一次设备影子数据
        this.dataInterval = setInterval(() => {
            console.log("定时获取设备数据...");
            this.getshadow();
        }, 5000);
        
        // 每秒更新一次时间
        this.timeInterval = setInterval(() => {
            this.updateCurrentTime();
        }, 1000);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
        // 页面卸载时清除定时器，防止内存泄漏
        if (this.dataInterval) {
            clearInterval(this.dataInterval);
            this.dataInterval = null;
        }
        if (this.timeInterval) {
            clearInterval(this.timeInterval);
            this.timeInterval = null;
        }
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})