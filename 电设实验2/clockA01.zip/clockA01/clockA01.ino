#include <SPI.h>
#include <Wire.h>
#include <RTClib.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>
#include <DHT.h>

// 定义屏幕引脚
#define TFT_CS   8
#define TFT_DC   9
#define TFT_RES  10

// 编码器引脚
#define ENC_CLK 2
#define ENC_DT  3
#define ENC_SW  4

// 闹钟输出引脚
#define ALARM_OUTPUT_PIN 5

// DFPlayer 软串口引脚
#define DFPLAYER_RX 6
#define DFPLAYER_TX 7

// DHT11引脚定义
#define DHTPIN A0
#define DHTTYPE DHT11

// 光敏传感器引脚定义
#define LIGHT_SENSOR_PIN A1  // 数字输出型光敏传感器

// 时钟显示模式
enum ClockDisplayMode {
  CLOCK_DIGITAL,
  CLOCK_ANALOG
};
ClockDisplayMode clockMode = CLOCK_ANALOG;

// ===== 配色方案 =====
enum ColorScheme {
  SCHEME_DARK,
  SCHEME_LIGHT
};
ColorScheme currentScheme = SCHEME_DARK;

// 深色方案颜色定义
const uint16_t DARK_BG      = ST7735_BLACK;
const uint16_t DARK_TEXT     = ST7735_WHITE;
const uint16_t DARK_HIGHLIGHT = ST7735_YELLOW;
const uint16_t DARK_ACCENT1  = ST7735_GREEN;
const uint16_t DARK_ACCENT2  = ST7735_BLUE;
const uint16_t DARK_ACCENT3  = ST7735_RED;
const uint16_t DARK_ACCENT4  = ST7735_CYAN;
const uint16_t DARK_CLOCK_FACE = ST7735_WHITE;
const uint16_t DARK_CLOCK_CENTER = ST7735_RED;
const uint16_t DARK_HOUR_HAND = ST7735_BLUE;
const uint16_t DARK_MIN_HAND  = ST7735_GREEN;
const uint16_t DARK_SEC_HAND  = ST7735_RED;
const uint16_t DARK_ARROW     = ST7735_BLUE;
const uint16_t DARK_ON_COLOR  = ST7735_GREEN;
const uint16_t DARK_OFF_COLOR = ST7735_RED;

// 浅色方案颜色定义 - 加深绿色使其更醒目
const uint16_t LIGHT_BG      = ST7735_WHITE;
const uint16_t LIGHT_TEXT     = ST7735_BLACK;
const uint16_t LIGHT_HIGHLIGHT = 0xFD20;  // 橙色
const uint16_t LIGHT_ACCENT1  = 0x03E0;  // 深绿色
const uint16_t LIGHT_ACCENT2  = 0x001F;  // 深蓝色
const uint16_t LIGHT_ACCENT3  = 0xF800;  // 深红色
const uint16_t LIGHT_ACCENT4  = 0x04DF;  // 深青色
const uint16_t LIGHT_CLOCK_FACE = ST7735_BLACK;
const uint16_t LIGHT_CLOCK_CENTER = 0xF800;  // 红色
const uint16_t LIGHT_HOUR_HAND = 0x001F;  // 深蓝色
const uint16_t LIGHT_MIN_HAND  = 0x03E0;  // 深绿色
const uint16_t LIGHT_SEC_HAND  = 0xF800;  // 深红色
const uint16_t LIGHT_ARROW     = 0xFD20;  // 橙色
const uint16_t LIGHT_ON_COLOR  = 0x03E0;  // 深绿色
const uint16_t LIGHT_OFF_COLOR = 0xF800;  // 深红色

// 当前使用的颜色变量
uint16_t BG_COLOR;
uint16_t TEXT_COLOR;
uint16_t HIGHLIGHT_COLOR;
uint16_t ACCENT1_COLOR;
uint16_t ACCENT2_COLOR;
uint16_t ACCENT3_COLOR;
uint16_t ACCENT4_COLOR;
uint16_t CLOCK_FACE_COLOR;
uint16_t CLOCK_CENTER_COLOR;
uint16_t HOUR_HAND_COLOR;
uint16_t MIN_HAND_COLOR;
uint16_t SEC_HAND_COLOR;
uint16_t ARROW_COLOR;
uint16_t ON_COLOR;
uint16_t OFF_COLOR;

// 闹钟数据结构
struct Alarm {
  uint8_t hour;
  uint8_t minute;
  bool enabled;
  bool triggered;
};

// 创建对象
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RES);
RTC_DS3231 rtc;
SoftwareSerial mySoftwareSerial(DFPLAYER_RX, DFPLAYER_TX);
DFRobotDFPlayerMini myDFPlayer;
DHT dht(DHTPIN, DHTTYPE);

// ===== 全局状态 =====
enum SystemMode {
  MODE_CLOCK,
  MODE_ALARM_SET,
  MODE_ALARM_RINGING
};
SystemMode currentMode = MODE_CLOCK;

// ===== 时钟模式变量 =====
char CurrentTime[9];
char CurrentDate[11];
char lastTime[9] = "00:00:00";
char lastDate[11] = "0000/00/00";
unsigned long lastClockUpdate = 0;
const long clockInterval = 1000;

// ===== 模拟时钟变量 =====
const byte clockCenterX = 80;
const byte clockCenterY = 55;
const byte clockRadius = 50;
int lastHour = -1;
int lastMinute = -1;
int lastSecond = -1;

// ===== 闹钟设置模式变量 =====
Alarm alarms[4] = {
  {7, 0, true, false},
  {8, 0, true, false},
  {9, 0, false, false},
  {18, 30, false, false}
};

// 自动配色开关
bool autoColorEnabled = true;  // 默认开启自动配色

byte currentAlarmIndex = 0;
byte currentField = 0;
bool inAlarmSelectMode = true;

// ===== 闹钟响铃模式变量 =====
int ringingAlarmIndex = -1;
unsigned long alarmStartTime = 0;
const unsigned long alarmDuration = 60000;
bool alarmOutputState = false;
unsigned long lastAlarmToggleTime = 0;
const int alarmBlinkInterval = 500;

// ===== 日期追踪 =====
int lastDay = -1;

// ===== 编码器变量 =====
int encoderValue = 0;
int lastEncoderValue = 0;
int encoderPinA = HIGH;
int encoderPinB = HIGH;
int lastEncoderPinA = HIGH;
unsigned long lastEncoderReadTime = 0;
const int encoderReadInterval = 2;
int encoderCount = 0;
const int encoderThreshold = 2;

// ===== 按键变量 =====
unsigned long buttonPressTime = 0;
bool buttonPressed = false;
const long longPressTime = 600;

// ===== 显示变量 =====
unsigned long lastBlinkTime = 0;
bool blinkState = false;
int lastSelectedAlarmIndex = 0;

// ===== DHT11变量 =====
float lastTemp = 0.0;
float lastHumidity = 0.0;
unsigned long lastDHTRead = 0;
const long dhtInterval = 2000;
bool dhtInitialized = false;

// ===== 光敏传感器变量 =====
bool lastLightState = HIGH;
unsigned long lastLightCheck = 0;
const long lightCheckInterval = 500;

// ===== 函数声明 =====
void updateColorScheme();
void drawSchemeIndicator();
void switchColorScheme();
void checkLightSensor();

void setup() {
  // 初始化光敏传感器引脚
  pinMode(LIGHT_SENSOR_PIN, INPUT);
  
  // 初始化颜色方案
  updateColorScheme();
  
  // 初始化 DHT11
  dht.begin();
  dhtInitialized = true;
  
  // 初始化 DFPlayer
  mySoftwareSerial.begin(9600);
  myDFPlayer.begin(mySoftwareSerial);
  myDFPlayer.volume(20);
  
  // 初始化闹钟输出引脚
  pinMode(ALARM_OUTPUT_PIN, OUTPUT);
  digitalWrite(ALARM_OUTPUT_PIN, HIGH);
  
  tft.initR(INITR_GREENTAB);
  tft.setRotation(1);
  tft.fillScreen(BG_COLOR);
  
  // 初始化编码器
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  lastEncoderPinA = digitalRead(ENC_CLK);
  
  // 初始化RTC
  if (!rtc.begin()) {
    tft.setCursor(10, 10);
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
    tft.print(F("RTC Error"));
    while(1);
  }
  
  // 获取当前日期
  DateTime now = rtc.now();
  lastDay = now.day();
  
  // 绘制静态时钟表盘
  drawClockFace();
  
  // 显示初始界面
  updateClockDisplay();
}

void loop() {
  // 读取DHT11温湿度
  readDHT11();
  
  // 检查光线传感器（仅在自动配色开启时）
  if (autoColorEnabled) {
    checkLightSensor();
  }
  
  // 检查闹钟
  checkAlarms();
  
  // 处理闹钟响铃状态
  if (currentMode == MODE_ALARM_RINGING) {
    handleAlarmRinging();
  }
  
  // 轮询编码器
  if (millis() - lastEncoderReadTime >= encoderReadInterval) {
    lastEncoderReadTime = millis();
    readEncoder();
  }
  
  // 处理编码器旋转
  if (encoderValue != lastEncoderValue) {
    int delta = encoderValue - lastEncoderValue;
    lastEncoderValue = encoderValue;
    
    if (delta > 0) delta = 1;
    if (delta < 0) delta = -1;
    
    if (currentMode == MODE_CLOCK) {
      handleClockRotation(delta);
    } else if (currentMode == MODE_ALARM_SET) {
      handleAlarmRotation(delta);
    }
  }
  
  // 处理编码器按键
  handleEncoderButton();
  
  // 根据当前模式更新显示
  if (currentMode == MODE_CLOCK) {
    if (millis() - lastClockUpdate >= clockInterval) {
      lastClockUpdate = millis();
      updateClockDisplay();
    }
  } else if (currentMode == MODE_ALARM_SET) {
    if (millis() - lastBlinkTime > 500) {
      lastBlinkTime = millis();
      blinkState = !blinkState;
      
      if (!inAlarmSelectMode) {
        if (currentField == 0) {
          blinkHourField();
        } else if (currentField == 1) {
          blinkMinuteField();
        } else if (currentField == 2) {
          blinkSwitchField();
        } else if (currentField == 3) {
          blinkAutoColorField();
        }
      }
    }
  }
}

// ===== 光敏传感器检测函数 =====
void checkLightSensor() {
  if (millis() - lastLightCheck < lightCheckInterval) return;
  lastLightCheck = millis();
  
  bool currentLightState = digitalRead(LIGHT_SENSOR_PIN);
  
  if (currentLightState != lastLightState) {
    lastLightState = currentLightState;
    
    if (currentLightState == HIGH) {
      if (currentScheme != SCHEME_DARK) {
        switchColorScheme();
      }
    } else {
      if (currentScheme != SCHEME_LIGHT) {
        switchColorScheme();
      }
    }
  }
}

// ===== 更新配色方案 =====
void updateColorScheme() {
  if (currentScheme == SCHEME_DARK) {
    BG_COLOR = DARK_BG;
    TEXT_COLOR = DARK_TEXT;
    HIGHLIGHT_COLOR = DARK_HIGHLIGHT;
    ACCENT1_COLOR = DARK_ACCENT1;
    ACCENT2_COLOR = DARK_ACCENT2;
    ACCENT3_COLOR = DARK_ACCENT3;
    ACCENT4_COLOR = DARK_ACCENT4;
    CLOCK_FACE_COLOR = DARK_CLOCK_FACE;
    CLOCK_CENTER_COLOR = DARK_CLOCK_CENTER;
    HOUR_HAND_COLOR = DARK_HOUR_HAND;
    MIN_HAND_COLOR = DARK_MIN_HAND;
    SEC_HAND_COLOR = DARK_SEC_HAND;
    ARROW_COLOR = DARK_ARROW;
    ON_COLOR = DARK_ON_COLOR;
    OFF_COLOR = DARK_OFF_COLOR;
  } else {
    BG_COLOR = LIGHT_BG;
    TEXT_COLOR = LIGHT_TEXT;
    HIGHLIGHT_COLOR = LIGHT_HIGHLIGHT;
    ACCENT1_COLOR = LIGHT_ACCENT1;
    ACCENT2_COLOR = LIGHT_ACCENT2;
    ACCENT3_COLOR = LIGHT_ACCENT3;
    ACCENT4_COLOR = LIGHT_ACCENT4;
    CLOCK_FACE_COLOR = LIGHT_CLOCK_FACE;
    CLOCK_CENTER_COLOR = LIGHT_CLOCK_CENTER;
    HOUR_HAND_COLOR = LIGHT_HOUR_HAND;
    MIN_HAND_COLOR = LIGHT_MIN_HAND;
    SEC_HAND_COLOR = LIGHT_SEC_HAND;
    ARROW_COLOR = LIGHT_ARROW;
    ON_COLOR = LIGHT_ON_COLOR;
    OFF_COLOR = LIGHT_OFF_COLOR;
  }
}

// ===== 切换配色方案 =====
void switchColorScheme() {
  if (currentScheme == SCHEME_DARK) {
    currentScheme = SCHEME_LIGHT;
  } else {
    currentScheme = SCHEME_DARK;
  }
  
  updateColorScheme();
  
  tft.fillScreen(BG_COLOR);
  if (clockMode == CLOCK_ANALOG) {
    drawClockFace();
  }
  
  lastHour = -1;
  lastMinute = -1;
  lastSecond = -1;
  
  updateClockDisplay();
  drawSchemeIndicator();
}

// ===== 显示配色方案指示器 =====
void drawSchemeIndicator() {
  tft.fillRect(140, 0, 20, 10, BG_COLOR);
  tft.setTextSize(1);
  tft.setCursor(142, 2);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  if (currentScheme == SCHEME_DARK) {
    tft.print(F("D"));
  } else {
    tft.print(F("L"));
  }
}

// ===== DHT11读取函数 =====
void readDHT11() {
  if (!dhtInitialized) return;
  
  if (millis() - lastDHTRead >= dhtInterval) {
    lastDHTRead = millis();
    
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    
    if (!isnan(h) && !isnan(t)) {
      lastHumidity = h;
      lastTemp = t;
    }
  }
}

// ===== 时钟模式旋转处理 =====
void handleClockRotation(int delta) {
  if (!autoColorEnabled) {
    switchColorScheme();
  }
}

// ===== 检查闹钟 =====
void checkAlarms() {
  DateTime now = rtc.now();
  
  if (now.day() != lastDay) {
    for (byte i = 0; i < 4; i++) {
      alarms[i].triggered = false;
    }
    lastDay = now.day();
  }
  
  if (currentMode == MODE_ALARM_RINGING) {
    return;
  }
  
  for (byte i = 0; i < 4; i++) {
    if (alarms[i].enabled && !alarms[i].triggered) {
      if (now.hour() == alarms[i].hour && now.minute() == alarms[i].minute && now.second() == 0) {
        triggerAlarm(i);
        break;
      }
    }
  }
}

// ===== 触发闹钟 =====
void triggerAlarm(int alarmIndex) {
  ringingAlarmIndex = alarmIndex;
  alarms[alarmIndex].triggered = true;
  currentMode = MODE_ALARM_RINGING;
  alarmStartTime = millis();
  lastAlarmToggleTime = millis();
  alarmOutputState = false;
  digitalWrite(ALARM_OUTPUT_PIN, LOW);
  
  myDFPlayer.stop();
  delay(100);
  myDFPlayer.volume(25);
  delay(50);
  myDFPlayer.play(1);
  delay(50);
  
  tft.fillScreen(BG_COLOR);
  displayAlarmRinging();
  drawSchemeIndicator();
}

// ===== 处理闹钟响铃 =====
void handleAlarmRinging() {
  unsigned long currentMillis = millis();
  
  if (currentMillis - alarmStartTime >= alarmDuration) {
    stopAlarm();
    return;
  }
  
  if (currentMillis - lastAlarmToggleTime >= alarmBlinkInterval) {
    lastAlarmToggleTime = currentMillis;
    alarmOutputState = !alarmOutputState;
    digitalWrite(ALARM_OUTPUT_PIN, alarmOutputState ? HIGH : LOW);
    
    blinkState = !blinkState;
    displayAlarmRinging();
  }
}

// ===== 停止闹钟 =====
void stopAlarm() {
  digitalWrite(ALARM_OUTPUT_PIN, HIGH);
  
  if (myDFPlayer.available()) {
    myDFPlayer.stop();
  }
  
  currentMode = MODE_CLOCK;
  ringingAlarmIndex = -1;
  tft.fillScreen(BG_COLOR);
  if (clockMode == CLOCK_ANALOG) {
    drawClockFace();
  }
  
  lastHour = -1;
  lastMinute = -1;
  lastSecond = -1;
  
  updateClockDisplay();
  drawSchemeIndicator();
}

// ===== 显示闹钟响铃界面 =====
void displayAlarmRinging() {
  tft.setTextSize(2);
  tft.setTextColor(ACCENT3_COLOR, BG_COLOR);
  tft.setCursor(20, 30);
  
  if (blinkState) {
    tft.print(F("ALARM!"));
  } else {
    tft.fillRect(20, 30, 120, 20, BG_COLOR);
  }
  
  tft.setTextSize(1);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  tft.setCursor(10, 60);
  tft.print(F("Alarm "));
  tft.print(ringingAlarmIndex + 1);
  tft.print(F(": "));
  
  if (alarms[ringingAlarmIndex].hour < 10) tft.print(F("0"));
  tft.print(alarms[ringingAlarmIndex].hour);
  tft.print(F(":"));
  if (alarms[ringingAlarmIndex].minute < 10) tft.print(F("0"));
  tft.print(alarms[ringingAlarmIndex].minute);
  
  tft.setCursor(10, 80);
  tft.print(F("Press to stop"));
  
  unsigned long remaining = (alarmDuration - (millis() - alarmStartTime)) / 1000;
  tft.setCursor(10, 100);
  tft.print(F("Auto stop: "));
  tft.print(remaining);
  tft.print(F("s"));
  
  drawSchemeIndicator();
}

// ===== 编码器读取 =====
void readEncoder() {
  encoderPinA = digitalRead(ENC_CLK);
  encoderPinB = digitalRead(ENC_DT);
  
  if (encoderPinA != lastEncoderPinA) {
    if (encoderPinA == LOW) {
      if (encoderPinB == HIGH) {
        encoderCount++;
      } else {
        encoderCount--;
      }
      
      if (abs(encoderCount) >= encoderThreshold) {
        if (encoderCount > 0) {
          encoderValue++;
        } else {
          encoderValue--;
        }
        encoderCount = 0;
      }
    }
    lastEncoderPinA = encoderPinA;
  }
}

// ===== 按键处理 =====
void handleEncoderButton() {
  if (digitalRead(ENC_SW) == LOW) {
    if (!buttonPressed) {
      buttonPressTime = millis();
      buttonPressed = true;
    }
  } else {
    if (buttonPressed) {
      unsigned long pressDuration = millis() - buttonPressTime;
      
      if (pressDuration > 50) {
        if (pressDuration > longPressTime) {
          if (currentMode == MODE_ALARM_RINGING) {
            stopAlarm();
          } else {
            switchMode();
          }
        } else {
          handleShortPress();
        }
      }
      buttonPressed = false;
      
      while(digitalRead(ENC_SW) == LOW) delay(10);
    }
  }
}

// ===== 切换模式 =====
void switchMode() {
  if (currentMode == MODE_CLOCK) {
    currentMode = MODE_ALARM_SET;
    inAlarmSelectMode = true;
    currentAlarmIndex = 0;
    currentField = 0;
    tft.fillScreen(BG_COLOR);
    tft.setTextSize(1);
    displayAlarmList();
    lastSelectedAlarmIndex = currentAlarmIndex;
    drawSchemeIndicator();
  } else if (currentMode == MODE_ALARM_SET) {
    currentMode = MODE_CLOCK;
    tft.fillScreen(BG_COLOR);
    if (clockMode == CLOCK_ANALOG) {
      drawClockFace();
    }
    
    lastHour = -1;
    lastMinute = -1;
    lastSecond = -1;
    
    updateClockDisplay();
    drawSchemeIndicator();
  }
}

// ===== 短按处理 =====
void handleShortPress() {
  if (currentMode == MODE_CLOCK) {
    if (clockMode == CLOCK_DIGITAL) {
      clockMode = CLOCK_ANALOG;
      tft.fillScreen(BG_COLOR);
      drawClockFace();
    } else {
      clockMode = CLOCK_DIGITAL;
      tft.fillScreen(BG_COLOR);
    }
    
    lastHour = -1;
    lastMinute = -1;
    lastSecond = -1;
    
    updateClockDisplay();
    drawSchemeIndicator();
    
  } else if (currentMode == MODE_ALARM_SET) {
    if (inAlarmSelectMode) {
      inAlarmSelectMode = false;
      currentField = 0;
      tft.fillScreen(BG_COLOR);
      tft.setTextSize(3);
      displayAlarmSetting();
      drawSchemeIndicator();
    } else {
      currentField++;
      if (currentField > 3) {
        inAlarmSelectMode = true;
        tft.fillScreen(BG_COLOR);
        tft.setTextSize(1);
        displayAlarmList();
        drawSchemeIndicator();
      } else {
        updateFieldIndicator();
        if (currentField == 0 || currentField == 1) {
          updateTimeField();
        } else if (currentField == 2) {
          updateSwitchField();
        } else if (currentField == 3) {
          updateAutoColorField();
        }
      }
    }
  } else if (currentMode == MODE_ALARM_RINGING) {
    stopAlarm();
  }
}

// ===== 闹钟旋转处理 =====
void handleAlarmRotation(int delta) {
  if (inAlarmSelectMode) {
    int newIndex = currentAlarmIndex + delta;
    if (newIndex < 0) newIndex = 3;
    if (newIndex > 3) newIndex = 0;
    
    if (newIndex != currentAlarmIndex) {
      currentAlarmIndex = newIndex;
      updateAlarmListSelection();
    }
  } else {
    adjustCurrentField(delta);
    
    if (currentField == 0 || currentField == 1) {
      updateTimeField();
    } else if (currentField == 2) {
      updateSwitchField();
    } else if (currentField == 3) {
      updateAutoColorField();
    }
  }
}

// ===== 调整当前字段 =====
void adjustCurrentField(int delta) {
  Alarm& a = alarms[currentAlarmIndex];
  
  switch(currentField) {
    case 0:
      a.hour = (a.hour + delta + 24) % 24;
      a.triggered = false;
      break;
    case 1:
      a.minute = (a.minute + delta + 60) % 60;
      a.triggered = false;
      break;
    case 2:
      if (delta != 0) {
        a.enabled = !a.enabled;
        a.triggered = false;
      }
      break;
    case 3:
      if (delta != 0) {
        autoColorEnabled = !autoColorEnabled;
      }
      break;
  }
  
  if (currentMode == MODE_ALARM_RINGING && ringingAlarmIndex == currentAlarmIndex) {
    stopAlarm();
  }
}

// ===== 绘制时钟表盘 =====
void drawClockFace() {
  tft.drawCircle(clockCenterX, clockCenterY, clockRadius, CLOCK_FACE_COLOR);
  tft.drawCircle(clockCenterX, clockCenterY, clockRadius + 1, CLOCK_FACE_COLOR);
  
  tft.fillCircle(clockCenterX, clockCenterY, 3, CLOCK_CENTER_COLOR);
  
  for (int i = 0; i < 12; i++) {
    float angle = (i * 30 - 90) * PI / 180;
    int x1, y1, x2, y2;
    
    if (i % 3 == 0) {
      x1 = clockCenterX + (clockRadius - 8) * cos(angle);
      y1 = clockCenterY + (clockRadius - 8) * sin(angle);
      x2 = clockCenterX + (clockRadius) * cos(angle);
      y2 = clockCenterY + (clockRadius) * sin(angle);
    } else {
      x1 = clockCenterX + (clockRadius - 4) * cos(angle);
      y1 = clockCenterY + (clockRadius - 4) * sin(angle);
      x2 = clockCenterX + (clockRadius) * cos(angle);
      y2 = clockCenterY + (clockRadius) * sin(angle);
    }
    
    tft.drawLine(x1, y1, x2, y2, CLOCK_FACE_COLOR);
  }
}

// ===== 绘制指针 =====
void drawHand(float angle, int length, int width, uint16_t color, bool draw) {
  float rad = angle * PI / 180;
  int x = clockCenterX + length * cos(rad);
  int y = clockCenterY + length * sin(rad);
  
  if (draw) {
    tft.drawLine(clockCenterX, clockCenterY, x, y, color);
    if (width > 1) {
      tft.drawLine(clockCenterX + 1, clockCenterY, x + 1, y, color);
      tft.drawLine(clockCenterX - 1, clockCenterY, x - 1, y, color);
    }
  } else {
    tft.drawLine(clockCenterX, clockCenterY, x, y, BG_COLOR);
    if (width > 1) {
      tft.drawLine(clockCenterX + 1, clockCenterY, x + 1, y, BG_COLOR);
      tft.drawLine(clockCenterX - 1, clockCenterY, x - 1, y, BG_COLOR);
    }
  }
}

// ===== 更新模拟时钟 =====
void updateAnalogClock(DateTime now) {
  float secondAngle = (now.second() * 6) - 90;
  float minuteAngle = (now.minute() * 6) + (now.second() * 0.1) - 90;
  float hourAngle = (now.hour() % 12 * 30) + (now.minute() * 0.5) - 90;
  
  if (lastSecond != -1) {
    float oldSecondAngle = (lastSecond * 6) - 90;
    drawHand(oldSecondAngle, clockRadius - 10, 1, SEC_HAND_COLOR, false);
  }
  if (lastMinute != -1) {
    float oldMinuteAngle = (lastMinute * 6) + (lastSecond * 0.1) - 90;
    drawHand(oldMinuteAngle, clockRadius - 15, 2, MIN_HAND_COLOR, false);
  }
  if (lastHour != -1) {
    float oldHourAngle = (lastHour % 12 * 30) + (lastMinute * 0.5) - 90;
    drawHand(oldHourAngle, clockRadius - 25, 3, HOUR_HAND_COLOR, false);
  }
  
  drawHand(secondAngle, clockRadius - 10, 1, SEC_HAND_COLOR, true);
  drawHand(minuteAngle, clockRadius - 15, 2, MIN_HAND_COLOR, true);
  drawHand(hourAngle, clockRadius - 25, 3, HOUR_HAND_COLOR, true);
  
  tft.fillCircle(clockCenterX, clockCenterY, 3, CLOCK_CENTER_COLOR);
  
  lastHour = now.hour();
  lastMinute = now.minute();
  lastSecond = now.second();
}

// ===== 时钟模式显示 =====
void updateClockDisplay() {
  DateTime now = rtc.now();
  
  if (clockMode == CLOCK_DIGITAL) {
    sprintf(CurrentTime, "%02d:%02d:%02d", 
            now.hour(), now.minute(), now.second());
    
    sprintf(CurrentDate, "%04d/%02d/%02d", 
            now.year(), now.month(), now.day());
    
    if (strcmp(CurrentTime, lastTime) != 0 || strcmp(CurrentDate, lastDate) != 0) {
      
      tft.setTextSize(2);
      tft.setTextColor(ACCENT1_COLOR, BG_COLOR);
      tft.setCursor(15, 5);
      tft.print(CurrentDate);
      
      tft.setTextSize(3);
      tft.setTextColor(ACCENT2_COLOR, BG_COLOR);
      tft.setCursor(10, 30);
      tft.print(CurrentTime);
      
      tft.setTextSize(1);
      tft.setTextColor(ACCENT4_COLOR, BG_COLOR);
      tft.setCursor(10, 70);
      tft.print(F("Temp: "));
      tft.print(lastTemp, 1);
      tft.print(F(" C"));
      
      tft.setCursor(10, 82);
      tft.print(F("Humi: "));
      tft.print(lastHumidity, 0);
      tft.print(F("%"));
      
      tft.setTextColor(TEXT_COLOR, BG_COLOR);
      tft.setCursor(10, 102);
      tft.print(F("Long press: settings"));
      tft.setCursor(10, 114);
      if (autoColorEnabled) {
        tft.print(F("Auto color ON"));
      } else {
        tft.print(F("Rotate: color"));
      }
      
      strcpy(lastTime, CurrentTime);
      strcpy(lastDate, CurrentDate);
    }
  } else {
    updateAnalogClock(now);
    
    sprintf(CurrentTime, "%02d:%02d:%02d", 
            now.hour(), now.minute(), now.second());
    
    tft.setTextSize(1);
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
    tft.setCursor(10, 105);
    tft.print(CurrentTime);
    
    tft.setCursor(10, 115);
    tft.print(F("T:"));
    tft.print(lastTemp, 1);
    tft.print(F(" H:"));
    tft.print(lastHumidity, 0);
    tft.print(F("%"));
    
    tft.setCursor(120, 115);
    if (autoColorEnabled) {
      tft.print(F("AUTO"));
    }
  }
  
  drawSchemeIndicator();
}

// ===== 闹钟设置模式的所有函数 =====
void displayAlarmList() {
  tft.setTextSize(1);
  tft.setTextColor(ACCENT1_COLOR, BG_COLOR);
  tft.setCursor(10, 5);
  tft.println(F("Select Alarm"));
  
  for(byte i=0; i<4; i++) {
    int y = 20 + i * 22;  // 从20开始，为底部留出空间
    
    tft.setCursor(15, y);
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
    tft.print(F("Alarm "));
    tft.print(i+1);
    tft.print(F(":"));
    
    tft.setCursor(70, y);
    if (alarms[i].hour < 10) tft.print(F("0"));
    tft.print(alarms[i].hour);
    tft.print(F(":"));
    if (alarms[i].minute < 10) tft.print(F("0"));
    tft.print(alarms[i].minute);
    
    tft.setCursor(115, y);
    tft.setTextColor(alarms[i].enabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
    tft.print(alarms[i].enabled ? F("ON") : F("OFF"));
  }
  
  // 底部固定区域显示自动配色状态
  tft.drawLine(0, 108, 128, 108, TEXT_COLOR);  // 分隔线
  
  tft.setCursor(10, 112);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  tft.print(F("Auto Color:"));
  
  tft.setCursor(70, 112);
  tft.setTextColor(autoColorEnabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  tft.print(autoColorEnabled ? F("ON") : F("OFF"));
  
  tft.setCursor(100, 112);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  tft.print(F("Push"));
  
  drawArrow(currentAlarmIndex);
  drawSchemeIndicator();
}

void drawArrow(int index) {
  int y = 20 + index * 22;
  tft.fillTriangle(5, y+5, 2, y+2, 2, y+8, ARROW_COLOR);
}

void eraseArrow(int index) {
  int y = 20 + index * 22;
  tft.fillRect(2, y-2, 8, 12, BG_COLOR);
}

void updateAlarmListSelection() {
  eraseArrow(lastSelectedAlarmIndex);
  drawArrow(currentAlarmIndex);
  lastSelectedAlarmIndex = currentAlarmIndex;
}

void displayAlarmSetting() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.setTextSize(1);
  tft.setTextColor(ACCENT1_COLOR, BG_COLOR);
  tft.setCursor(10, 5);
  tft.print(F("Set Alarm "));
  tft.println(currentAlarmIndex + 1);
  
  // 时间显示区域
  tft.fillRect(10, 25, 140, 30, BG_COLOR);
  tft.setTextSize(3);
  
  tft.setCursor(20, 30);
  tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
  if (a.hour < 10) tft.print(F("0"));
  tft.print(a.hour);
  
  tft.setCursor(56, 30);
  tft.print(F(":"));
  
  tft.setCursor(74, 30);
  if (a.minute < 10) tft.print(F("0"));
  tft.print(a.minute);
  
  // 闹钟开关
  tft.setTextSize(2);
  tft.fillRect(40, 60, 60, 20, BG_COLOR);
  tft.setCursor(45, 62);
  tft.setTextColor(a.enabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  tft.print(a.enabled ? F("ON") : F("OFF"));
  
  // 自动配色开关 - 固定位置
  tft.setTextSize(1);
  tft.setCursor(10, 85);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  tft.print(F("Auto Color:"));
  
  tft.setCursor(70, 85);
  tft.setTextColor(autoColorEnabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  tft.print(autoColorEnabled ? F("ON") : F("OFF"));
  
  // 底部提示区域
  tft.drawLine(0, 100, 128, 100, TEXT_COLOR);  // 分隔线
  
  updateFieldIndicator();
  drawSchemeIndicator();
}

void updateTimeField() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.fillRect(10, 25, 140, 30, BG_COLOR);
  tft.setTextSize(3);
  
  tft.setCursor(20, 30);
  tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
  if (a.hour < 10) tft.print(F("0"));
  tft.print(a.hour);
  
  tft.setCursor(56, 30);
  tft.print(F(":"));
  
  tft.setCursor(74, 30);
  if (a.minute < 10) tft.print(F("0"));
  tft.print(a.minute);
}

void updateSwitchField() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.fillRect(40, 60, 60, 20, BG_COLOR);
  tft.setTextSize(2);
  tft.setCursor(45, 62);
  tft.setTextColor(a.enabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  tft.print(a.enabled ? F("ON") : F("OFF"));
}

// ===== 更新自动配色字段 =====
void updateAutoColorField() {
  tft.fillRect(70, 85, 30, 10, BG_COLOR);
  tft.setTextSize(1);
  tft.setCursor(70, 85);
  tft.setTextColor(autoColorEnabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  tft.print(autoColorEnabled ? F("ON") : F("OFF"));
}

// ===== 更新字段指示器 =====
void updateFieldIndicator() {
  tft.fillRect(10, 105, 140, 20, BG_COLOR);
  
  tft.setTextSize(1);
  tft.setTextColor(TEXT_COLOR, BG_COLOR);
  tft.setCursor(10, 107);
  
  tft.print(F("Editing: "));
  if (currentField == 0) {
    tft.print(F("Hour"));
  } else if (currentField == 1) {
    tft.print(F("Minute"));
  } else if (currentField == 2) {
    tft.print(F("On/Off"));
  } else {
    tft.print(F("Auto Color"));
  }
  
}

void blinkHourField() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.fillRect(20, 30, 36, 24, BG_COLOR);
  tft.setTextSize(3);
  tft.setCursor(20, 30);
  
  if (blinkState) {
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
    tft.print(F("  "));
  } else {
    tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
    if (a.hour < 10) tft.print(F("0"));
    tft.print(a.hour);
  }
  
  tft.setCursor(56, 30);
  tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
  tft.print(F(":"));
  
  tft.setCursor(74, 30);
  if (a.minute < 10) tft.print(F("0"));
  tft.print(a.minute);
}

void blinkMinuteField() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.fillRect(74, 30, 36, 24, BG_COLOR);
  tft.setTextSize(3);
  tft.setCursor(74, 30);
  
  if (blinkState) {
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
    tft.print(F("  "));
  } else {
    tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
    if (a.minute < 10) tft.print(F("0"));
    tft.print(a.minute);
  }
  
  tft.setCursor(20, 30);
  tft.setTextColor(HIGHLIGHT_COLOR, BG_COLOR);
  if (a.hour < 10) tft.print(F("0"));
  tft.print(a.hour);
  
  tft.setCursor(56, 30);
  tft.print(F(":"));
}

void blinkSwitchField() {
  Alarm& a = alarms[currentAlarmIndex];
  
  tft.fillRect(40, 60, 60, 20, BG_COLOR);
  tft.setTextSize(2);
  tft.setCursor(45, 62);
  
  if (blinkState) {
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
  } else {
    tft.setTextColor(a.enabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  }
  
  tft.print(a.enabled ? F("ON") : F("OFF"));
}

// ===== 自动配色字段闪烁 =====
void blinkAutoColorField() {
  tft.fillRect(70, 85, 30, 10, BG_COLOR);
  tft.setTextSize(1);
  tft.setCursor(70, 85);
  
  if (blinkState) {
    tft.setTextColor(TEXT_COLOR, BG_COLOR);
  } else {
    tft.setTextColor(autoColorEnabled ? ON_COLOR : OFF_COLOR, BG_COLOR);
  }
  
  tft.print(autoColorEnabled ? F("ON") : F("OFF"));
}